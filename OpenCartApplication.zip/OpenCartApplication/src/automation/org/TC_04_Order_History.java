package automation.org;

import org.testng.annotations.Test;
import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC_04_Order_History {
	ChromeDriver driver;
@BeforeMethod
	public void open_chrome() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("https://demo.opencart.com");
		driver.manage().window().maximize();
	}
@Test	
public void order_history() throws Exception {
 
	driver.findElementByXPath("//a[@class=\"dropdown-toggle\" and @title=\"My Account\"]").click();
	driver.findElementByXPath("//a[text()=\"Login\"]").click();
	TC_02_product_Comparison pc= new TC_02_product_Comparison();
	driver.findElementById("input-email").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx", 2, 1));
	driver.findElementById("input-password").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx", 4, 1));
	driver.findElementByXPath("//input[@value=\"Login\"]").click();
	driver.findElementByXPath("//a[@href=\"https://demo.opencart.com/index.php?route=common/home\"]").click();
	driver.findElementByXPath("//img[@src=\"https://demo.opencart.com/image/cache/catalog/demo/banners/iPhone6-1140x380.jpg\" and @alt=\"iPhone 6\"]").click();
	
	//driver.findElementByXPath(using)
	
	//driver.findElementByXPath(using)
	
	
}

}
