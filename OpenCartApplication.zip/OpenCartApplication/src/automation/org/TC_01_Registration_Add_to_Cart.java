package automation.org;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class TC_01_Registration_Add_to_Cart {
	
	public ChromeDriver driver;
@Test	
public void registration() throws IOException {
	
	driver.findElementByXPath("//a[@title=\"My Account\"]").click();
	driver.findElementByXPath("//a[text()=\"Register\" ]").click();
	FileInputStream fs =new FileInputStream("D:\\Java\\OpenCartApplication\\TestData.xlsx");
	XSSFWorkbook wk=new XSSFWorkbook(fs);
	XSSFSheet s1=wk.getSheet("Sheet1");
	
	
		XSSFRow r2=s1.getRow(0);
		XSSFCell c2=r2.getCell(1);
		XSSFRow r3=s1.getRow(1);
		XSSFCell c3=r3.getCell(1);
		XSSFRow r4=s1.getRow(2);
		XSSFCell c4=r4.getCell(1);
		XSSFRow r5=s1.getRow(3);
		XSSFCell c5=r5.getCell(1);
		XSSFRow r6=s1.getRow(4);
		XSSFCell c6=r6.getCell(1);
		XSSFRow r7=s1.getRow(5);
		XSSFCell c7=r7.getCell(1);
		
			
			driver.findElementByName("firstname").sendKeys(c2.getStringCellValue());
			String p=driver.findElementById("input-firstname").getAttribute("value");
			AssertJUnit.assertEquals(p, c2.getStringCellValue(),"Name is not correct");
			driver.findElementByName("lastname").sendKeys(c3.getStringCellValue());
			String q=driver.findElementByName("lastname").getAttribute("value");
			AssertJUnit.assertEquals(q, c3.getStringCellValue(),"Last name is not correct");
			driver.findElementByName("email").sendKeys(c4.getStringCellValue());
			String r=driver.findElementByName("email").getAttribute("value");
			AssertJUnit.assertEquals(r, c4.getStringCellValue(),"email is not correct");
			driver.findElementByName("telephone").sendKeys(""+(int)(c5.getNumericCellValue()));
			String s=driver.findElementByName("telephone").getAttribute("value");
			AssertJUnit.assertEquals(s, ""+(int)(c5.getNumericCellValue()),"telphone is not correct");
			driver.findElementByName("password").sendKeys(c6.getStringCellValue());
			String t=driver.findElementByName("password").getAttribute("value");
			AssertJUnit.assertEquals(t, c6.getStringCellValue(),"password is not correct");
			driver.findElementByName("confirm").sendKeys(c7.getStringCellValue());
		    String u=driver.findElementByName("confirm").getAttribute("value");
		    AssertJUnit.assertEquals(u, c7.getStringCellValue(),"confirm password is not correct");
			driver.findElementByName("agree").click();
			driver.findElementByXPath("//input[@type=\"submit\" and @value=\"Continue\" ]").click();
			String a =driver.findElementByXPath("//h1[text()=\"Your Account Has Been Created!\"]").getText();
			AssertJUnit.assertEquals(a, "Your Account Has Been Created!","Account has  not been successfully created");
			System.out.println("Account has been created successfully");
			
			driver.findElementByXPath("//a[text()=\"contact us\"]").click();
			String a1=driver.findElementByName("name").getAttribute("value");
			AssertJUnit.assertEquals(p,a1,"Name is not correct");
			String a2=driver.findElementByName("email").getAttribute("value");
			AssertJUnit.assertEquals(r, a2,"email is not correct");
			driver.findElementById("input-enquiry").sendKeys("This is to Change of Address/Phone number");
			driver.findElementByXPath("//input[@class=\"btn btn-primary\" and @type=\"submit\" and @value=\"Submit\"]").click();
			driver.findElementByXPath("//a[text()=\"Continue\"]").click();
			
	        driver.findElementByXPath("//img[@alt=\"iPhone 6\"]").click();
			driver.findElementByXPath("//a[contains (text(),\"Reviews\")]").click();
			//need to remove later
			
			FileInputStream fs1=new FileInputStream("D:\\Java\\OpenCartApplication\\ReviewProduct.xls");
			HSSFWorkbook wk1=new HSSFWorkbook(fs1);
			HSSFSheet h1=wk1.getSheet("Sheet1");
			HSSFRow f1=h1.getRow(1);
			HSSFCell g1=f1.getCell(0);
			HSSFCell g2=f1.getCell(1);
			HSSFRow f2=h1.getRow(2);
			HSSFCell g3=f2.getCell(0);
			HSSFCell g4=f2.getCell(1);
			driver.findElementById("input-review").sendKeys(g1.getStringCellValue());
			selectrating((int)g2.getNumericCellValue());
			driver.findElementById("button-review").click();
					driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);	
				    takescreenshot(driver,"D:\\Java\\OpenCartApplication\\err1.png");
			driver.findElementById("input-review").sendKeys(g3.getStringCellValue());
			
			driver.findElementByName("rating").sendKeys(""+(int)g4.getNumericCellValue());
			selectrating((int)g4.getNumericCellValue());
			driver.manage().timeouts().implicitlyWait(1000, TimeUnit.SECONDS);
			driver.findElementByXPath("//button[@type=\"button\" and @class=\"btn btn-primary\" and @id=\"button-review\"]").click();
			String s11=driver.findElementByXPath("//div[@class=\"alert alert-success alert-dismissible\"]").getText();
			//driver.findElementByXPath("//div[@class=\"alert alert-success alert-dismissible\"]").clear();
			//Assert.assertEquals(s11, "Thank you for your review. It has been submitted to the webmaster for approval.","review is not successful");
			System.out.println(s11);
			//driver.findElementByXPath("//div[@class=\"alert alert-success alert-dismissible\"]").clear();
			driver.findElementByXPath("//button[@type=\"button\" and @data-original-title=\"Add to Wish List\"]").click();
			String s12=driver.findElementByXPath("//div[@class=\"alert alert-success alert-dismissible\"]").getText();
			System.out.println(s12);
			//Assert.assertEquals(s12, " Success: You have added Samsung Galaxy Tab 10.1 to your wish list!","wishlist not successful");
			driver.findElementByXPath("//button[@type=\"button\" and @class=\"close\"]").click();
			String s13=driver.findElementByXPath("//span[contains (text(),\"Wish List\")]").getText();
			String s14=s13.substring(11,12);
			System.out.println(s14);
			int s15=Integer.valueOf(s14);
		    
			driver.findElementByXPath("//span[contains (text(),\"Wish List\")]").click();
			List<WebElement> rows=driver.findElementsByXPath("//table[@class=\"table table-bordered table-hover\"]//tbody//tr");
			 int s16=rows.size();
			  if (s15==s16) {
				  System.out.println("wishlist count is matching");
			  }
			  else {
				  System.out.println("wishlist count is not matching");
			  }
			 
            driver.findElementByXPath("//span[text()=\"Currency\"]").click();
            driver.findElementByName("EUR").click();
             String t1=driver.findElementByXPath("//div[@class=\"price\"]").getText();
            
			 File f= new File("D:\\Java\\OpenCartApplication\\flat_file.txt");
			f.createNewFile();
			FileWriter fw=new FileWriter(f);
			BufferedWriter bw= new BufferedWriter(fw);  
			bw.write(t1);
			bw.flush();
			
			driver.findElementByXPath("//span[text()=\"Currency\"]").click();
			driver.findElementByName("GBP").click();
			   String t2=driver.findElementByXPath("//div[@class=\"price\"]").getText();
			bw.append(t2);
			bw.flush();
			driver.findElementByXPath("//span[text()=\"Currency\"]").click();
			driver.findElementByName("USD").click();
			String t3=driver.findElementByXPath("//div[@class=\"price\"]").getText();
			bw.append(t3);
			bw.flush();
			bw.close();
			driver.findElementByXPath("//button[@type=\"button\" and @data-original-title=\"Add to Cart\"]").click();
			String t4=driver.findElementByXPath("//div[@class=\"alert alert-success alert-dismissible\"]").getText();
			System.out.println(t4);
			driver.findElementByXPath("//a[@data-toggle=\"tooltip\" and @data-original-title=\"Remove\"]").click();
			String t5=driver.findElementByXPath("//div[@class=\"alert alert-success alert-dismissible\"]").getText();
			System.out.println(t5);
			driver.findElementByXPath("//a[text()=\"Continue\" and @class=\"btn btn-primary\"]").click();
			driver.findElementByXPath("//a[text()=\"Logout\" and @class=\"list-group-item\"]").click();
			boolean h11=driver.findElementByXPath("//h1[text()=\"Account Logout\"]").isDisplayed();
			boolean h12=driver.findElementByXPath("//a[text()=\"Login\" and @class=\"list-group-item\"]").isDisplayed();
			if ((h11=true) && (h12=true)) {
				System.out.println("Acount logout successful");
			}
		}

@BeforeMethod
public void Openchrome()  {
	 System.setProperty("webdriver.chrome.driver","D:\\Maven\\Wipro\\chromedriver.exe");
	 driver=new ChromeDriver();
	 driver.get("https://demo.opencart.com/");
	 driver.manage().window().maximize();
	
}	
@AfterMethod
public void Close() {
	 driver.close();
}
 public void takescreenshot(WebDriver driver,String filepath) throws IOException {
	 TakesScreenshot srnsh=((TakesScreenshot)driver);
	 File srcfile=srnsh.getScreenshotAs(OutputType.FILE);
	 File destfile=new File(filepath);
	 FileUtils.copyFile(srcfile, destfile);
	 
}
public void selectrating(int x) {
	
	
	switch(x) {
	
	case 1:
		
		driver.findElementByXPath("//input[@name=\"rating\" and @value=\"1\"]").click();
		break;
	case 2:	
		driver.findElementByXPath("//input[@name=\"rating\" and @value=\"2\"]").click();
		break;
		
	case 3:	driver.findElementByXPath("//input[@name=\"rating\" and @value=\"3\"]").click();
	break;
	case 4:	driver.findElementByXPath("//input[@name=\"rating\" and @value=\"4\"]").click();
	break;	
	case 5:	driver.findElementByXPath("//input[@name=\"rating\" and @value=\"5\"]").click();
	break;
	
	}
	
}
	
}
