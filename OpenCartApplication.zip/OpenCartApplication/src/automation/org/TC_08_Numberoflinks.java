package automation.org;

import org.testng.annotations.Test;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TC_08_Numberoflinks {

	public  ChromeDriver driver;
@BeforeMethod	
public void open_chrome() {
	System.setProperty("webdriver.chrome.driver","D:\\Maven\\Wipro\\chromedriver.exe");
	driver= new ChromeDriver();
	driver.get("https://demo.opencart.com/");
	 driver.manage().window().maximize();	
	 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
}
@Test 
public void Total_Amount() throws IOException  {
	driver.findElementByXPath("//a[@class=\"dropdown-toggle\" and @title=\"My Account\"]").click();
	driver.findElementByXPath("//a[text()=\"Login\"]").click();
	TC_02_product_Comparison pc= new TC_02_product_Comparison();
	driver.findElementById("input-email").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx", 2, 1));
	driver.findElementById("input-password").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx", 4, 1));
	driver.findElementByXPath("//input[@type=\"submit\" and @value=\"Login\"]").click();
	List<WebElement> alllinks=driver.findElementsByTagName("a");
	
	
		System.out.println(alllinks.size());
		JFrame f=new JFrame();
		JOptionPane.showMessageDialog(f, alllinks.size());
		driver.findElementByXPath("//a[text()=\"Logout\" and @class=\"list-group-item\"]").click();
		boolean h11=driver.findElementByXPath("//h1[text()=\"Account Logout\"]").isDisplayed();
		boolean h12=driver.findElementByXPath("//a[text()=\"Login\" and @class=\"list-group-item\"]").isDisplayed();
		if ((h11=true) && (h12=true)) {
			System.out.println("Acount logout successful");
		}

	
}
}
