package automation.org;



import org.testng.annotations.Test;
import java.io.IOException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TC03_Adding_Phones_to_cart {
	ChromeDriver driver;
@BeforeMethod	
public void open_chrome() {
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
	driver.get("https://demo.opencart.com/ ");
	driver.manage().window().maximize();
	//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	
}
@Test
public void Adding_Phones() throws IOException {
	driver.findElementByXPath("//a[@title=\"My Account\"]").click();
	driver.findElementByXPath("//a[text()=\"Login\"]").click();
	TC_02_product_Comparison pc= new TC_02_product_Comparison();
	 driver.findElementByName("email").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx",2,1));
	 driver.findElementByName("password").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx",4,1));
	 driver.findElementByXPath("//input[@type=\"submit\" and @value=\"Login\"]").click();
	 driver.findElementByXPath("//a[@href=\"https://demo.opencart.com/index.php?route=common/home\"]").click();
	 driver.findElementByXPath("//img[@alt=\"iPhone 6\"]").click();
	 driver.findElementByXPath("//img[@title=\"Samsung Galaxy Tab 10.1\" and @src=\"https://demo.opencart.com/image/cache/catalog/demo/samsung_tab_1-228x228.jpg\"]").click();
	Boolean b= driver.findElementByXPath("//img[@class=\"mfp-img\" and @src=\"https://demo.opencart.com/image/cache/catalog/demo/samsung_tab_1-500x500.jpg\"]").isDisplayed();
	
	if (b=true) {
	 System.out.println("tab is diplaying in model");
	}
	else {
		System.out.println("tab is not diplaying in model");	
	}
	String k1=driver.findElementByXPath("//div[@class=\"mfp-counter\"]").getText();
	String k2=(k1.substring(4).trim());
	int k3=Integer.valueOf(k2);
	System.out.println(k3);
	pc.write_in_file("D:\\Java\\OpenCartApplication\\flat_file5.txt",k1);
	 for (int i =0;i<k3-1;i++) {
		driver.findElementByXPath("//button[@title=\"Next (Right arrow key)\"]").click();
	 }
	 driver.findElementByXPath("//button[text()=\"�\"]") .click();
	 driver.findElementByXPath("//button[@id=\"button-cart\"]").click();
     driver.findElementByXPath("//a[@title=\"Checkout\"]").click();
 	driver.findElementByXPath("//a[@title=\"My Account\"]").click();
 	driver.findElementByXPath("//a[text()=\"Logout\"]").click();
		boolean h11=driver.findElementByXPath("//h1[text()=\"Account Logout\"]").isDisplayed();
		boolean h12=driver.findElementByXPath("//a[text()=\"Login\" and @class=\"list-group-item\"]").isDisplayed();
		if ((h11=true) && (h12=true)) {
			System.out.println("Acount logout successful");}
	
}
}
