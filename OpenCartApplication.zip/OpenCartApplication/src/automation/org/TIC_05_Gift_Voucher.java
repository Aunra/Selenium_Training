package automation.org;

import org.testng.annotations.Test;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Reader;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TIC_05_Gift_Voucher {
	ChromeDriver driver;
	@BeforeMethod
		public void open_chrome() {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.get("https://demo.opencart.com");
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		}
	@Test	
	public void gift_Voucher() throws Exception {
	 
		driver.findElementByXPath("//a[@class=\"dropdown-toggle\" and @title=\"My Account\"]").click();
		driver.findElementByXPath("//a[text()=\"Login\"]").click();
		TC_02_product_Comparison pc= new TC_02_product_Comparison();
		driver.findElementById("input-email").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx", 2, 1));
		driver.findElementById("input-password").sendKeys(pc.data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx", 4, 1));
		driver.findElementByXPath("//input[@value=\"Login\"]").click();
		driver.findElementByXPath("//a[text()=\"Gift Certificates\"]").click();
		File fh= new File("D:\\Java\\OpenCartApplication\\flat_file6.txt");
		FileReader fr= new FileReader(fh);
		BufferedReader br= new BufferedReader(fr);
		
		
		long t=2;
		
//		for (int i=0;i<t;i++) {
//			String t1= br.readLine();
//			driver.findElementById("input-to-name").sendKeys(t1.substring(0, 14));
//			
//		}
		
		driver.findElementById("input-to-name").sendKeys("Akhilesh Yadav");
		driver.findElementById("input-to-email").sendKeys("test@w.com");
		driver.findElementByXPath("//input[@type=\"radio\" and @name=\"voucher_theme_id\" and @value=\"7\"]").click();
		driver.findElementById("input-message").sendKeys("This is birthday gift");
		driver.findElementByName("agree").click();
		driver.findElementByXPath("//input[@type=\"submit\" and @value=\"Continue\" and @class=\"btn btn-primary\"]").click();
		driver.findElementByXPath("//a[@class=\"btn btn-primary\" and text()=\"Continue\"]").click();
		driver.findElementByXPath("//button[@type=\"button\" and @class=\"btn btn-danger\"]").click();
		driver.findElementByXPath("//a[@class=\"btn btn-default\" and text()=\"Continue Shopping\"]").click();
		driver.findElementByXPath("//a[@href=\"https://demo.opencart.com/index.php?route=common/home\"]").isDisplayed();
		driver.findElementByLinkText("Contact Us").click();
		driver.findElementById("input-enquiry").sendKeys("tttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttttgsdfsshg");
		driver.findElementByXPath("//input[@class=\"btn btn-primary\" and @value=\"Submit\"]").click();
		driver.findElementByXPath("//a[@class=\"btn btn-primary\" and text()=\"Continue\"]").click();
		driver.findElementByXPath("//a[text()=\"Wish List\"]").click();
		driver.findElementByXPath("//a[@class=\"btn btn-primary\" and text()=\"Continue\"]").click();
		driver.findElementByXPath("//a[text()=\"Edit your account information\"]").click();
		driver.findElementByName("telephone").clear();
		driver.findElementByName("telephone").sendKeys("123454578");
		
		driver.findElementByXPath("//input[@class=\"btn btn-primary\" and @value=\"Continue\" and @type=\"submit\"]").click();
		driver.findElementByXPath("//a[text()=\"View your return requests\"]").click();
		driver.findElementByXPath("//a[@class=\"btn btn-primary\" and text()=\"Continue\"]").click();
		driver.findElementByXPath("//a[@title=\"My Account\"]").click();
		driver.findElementByXPath("//a[text()=\"Logout\"]").click();
		boolean h11=driver.findElementByXPath("//h1[text()=\"Account Logout\"]").isDisplayed();
		boolean h12=driver.findElementByXPath("//a[text()=\"Login\" and @class=\"list-group-item\"]").isDisplayed();
		if ((h11=true) && (h12=true)) {
			System.out.println("Acount logout successful");}
		
}
}
