package automation.org;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver ;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class TC_02_product_Comparison {
	
	public  ChromeDriver driver;
@BeforeMethod	
public void open_chrome() {
	System.setProperty("webdriver.chrome.driver","D:\\Maven\\Wipro\\chromedriver.exe");
	driver= new ChromeDriver();
	driver.get("https://demo.opencart.com/");
	 driver.manage().window().maximize();	
	 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
}
@Test 
public void product_comparison() throws IOException, Exception  {
	driver.findElementByXPath("//a[@title=\"My Account\"]").click();
	driver.findElementByXPath("//a[text()=\"Login\"]").click();
    driver.findElementByName("email").sendKeys(data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx",2,1));
	driver.findElementByName("password").sendKeys(data_from_excel("D:\\Java\\OpenCartApplication\\TestData.xlsx",4,1));
	driver.findElementByXPath("//input[@type=\"submit\" and @value=\"Login\"]").click();
	driver.findElementByXPath("//input[@type=\"text\" and @name=\"search\" and @class=\"form-control input-lg\"]").sendKeys(data_from_excel("D:\\Java\\OpenCartApplication\\SearchProd.xlsx",0,0));
	driver.findElementByXPath("//button[@type=\"button\" and @class=\"btn btn-default btn-lg\"]").click();
	String b1=driver.findElementByXPath("//div[@class=\"col-sm-6 text-right\"]").getText();
	String[] b2=b1.split(" ");
	String b3=b2[5];
	System.out.println(b3);
	write_in_file("D:\\Java\\OpenCartApplication\\flat_file1.txt",b3);
	Select st= new Select (driver.findElementByXPath("//select[@name=\"category_id\" and @class=\"form-control\"]"));
	st.selectByValue("28");
	driver.findElementByXPath("//input[@value=\"Search\" and @id=\"button-search\"]").click();
	String c1=driver.findElementByXPath("//div[@class=\"col-sm-6 text-right\"]").getText();
	String[] c2=c1.split(" ");
	String c3=c2[5];
	System.out.println(c3);
	write_in_file("D:\\Java\\OpenCartApplication\\flat_file2.txt",c3);
	driver.findElementByXPath("//a[text()=\"Phones & PDAs\"]").click();
	String d1=driver.findElementByXPath("//div[@class=\"col-sm-6 text-right\"]").getText();
	String[] d2=d1.split(" ");
	String d3=d2[5];
	System.out.println(d3);
	write_in_file("D:\\Java\\OpenCartApplication\\flat_file3.txt",d3);
	Select d5= new Select (driver.findElementByXPath("//select[@id=\"input-sort\" and @class=\"form-control\"]"));
	d5.selectByVisibleText("Price (High > Low)");
	//String x=driver.findElementByXPath("//p[@class=\"price\"]").getText();
	//System.out.println(x);
	 double y=0.0;
	List<WebElement> l= driver.findElementsByXPath("//p[@class=\"price\"]");
	 for (WebElement ele : l) {
         String name = (ele.getText());
         String k=name.substring(1, 7);
         double x= Double.parseDouble(k);
      
       if (x>y){
    	   y=x;
       
     }
       }
       String k1=driver.findElementByXPath("//p[@class=\"price\"]").getText().substring(1,7);
       double k2=Double.parseDouble(k1);
       if (y==k2){
       System.out.println("phones are showing in highest to lowest order "+ y);
       
       List <WebElement> m= driver.findElementsByXPath("//a[contains (@href,\"https://demo.opencart.com/index.php?route=product/product&path=24&product_id\")]");
       File f1= new File("D:\\Java\\OpenCartApplication\\phone_name.txt");  
   	f1.createNewFile();
   	FileWriter fw1= new FileWriter(f1);
   	BufferedWriter bw1= new BufferedWriter(fw1);
       for (WebElement e: m) {
    	   String name1=e.getText();
    	   //System.out.println(name1);
    	
    	bw1.write(name1);
    	bw1.newLine();
    	bw1.flush();
    	
       }
       bw1.close();
         }
	 List<WebElement> d=driver.findElementsByXPath("//button[@type=\"button\" and @data-original-title=\"Compare this Product\"]//i[@class=\"fa fa-exchange\"]");
	 for (WebElement j:d) {
		 Thread.sleep(3000);
       
		 j.click();
		 Thread.sleep(1000);
		 driver.findElementByXPath("//button[@type=\"button\" and @class=\"close\"]").click();	
	}
	 driver.findElementById("compare-total").click();
	 File f2= new File("D:\\Java\\OpenCartApplication\\phone_name.txt");  
	FileReader fr=new FileReader(f2); 
	BufferedReader br= new BufferedReader(fr);
	String r;
	while ((r=br.readLine())!=null) {
		
	System.out.println(r);
	
	}
	
	String x=driver.findElementByXPath("//a[@href=\"https://demo.opencart.com/index.php?route=product/product&product_id=29\"]").getText();
	String u=driver.findElementByXPath("//a[@href=\"https://demo.opencart.com/index.php?route=product/product&product_id=28\"]").getText();
	String z=driver.findElementByXPath("//a[@href=\"https://demo.opencart.com/index.php?route=product/product&product_id=40\"]").getText();
	String h=x+u+z;
	boolean p=h.contains(h);
	if (p=true) {
		System.out.println("phones diplayed on the screen are correct");
	}
	else  { System.out.println("phones diplayed on the screen are not correct");
	}
	driver.findElementByXPath("//strong[text()=\"Palm Treo Pro\"]").click();
	//System.out.println(driver.findElementByXPath("//li[4]").getText());
	List<WebElement> i =driver.findElementsByXPath("//li");
    File f3=new File("D:\\Java\\OpenCartApplication\\phone_desc.txt");
	FileWriter fw2= new FileWriter(f3);
	BufferedWriter bw2=new BufferedWriter(fw2);
	
	for (WebElement w:i) {
    	w.getText();
    	System.out.println(w.getText());
    	bw2.write(w.getText());
    	bw2.newLine();
    	bw2.flush();
    	
    
    }
	bw2.close();
	driver.findElementByXPath("//button[@type=\"button\" and @id=\"button-cart\"]").click();
	driver.findElementByXPath("//span[text()=\"Checkout\"]").click();
	driver.findElementByXPath("//a[@title=\"My Account\"]").click();
	driver.findElementByXPath("//a[text()=\"Logout\"]").click();
	boolean h11=driver.findElementByXPath("//h1[text()=\"Account Logout\"]").isDisplayed();
	boolean h12=driver.findElementByXPath("//a[text()=\"Login\" and @class=\"list-group-item\"]").isDisplayed();
	if ((h11=true) && (h12=true)) {
		System.out.println("Acount logout successful");
	}
}


//@AfterMethod
public void close() {
	driver.close();
}

public String data_from_excel(String filepath,int r,int c) throws IOException {
	FileInputStream fs=new FileInputStream(filepath);
	XSSFWorkbook wk=new XSSFWorkbook(fs);
	XSSFSheet ws= wk.getSheet("Sheet1");
	XSSFRow r1=ws.getRow(r);
	XSSFCell c1=r1.getCell(c);
	String a=c1.getStringCellValue();
	return a;
}
//"D:\\Java\\OpenCartApplication\\flat_file1.txt"
public void write_in_file(String filepath,String data) throws IOException {
	File fh= new File(filepath);
	fh.createNewFile();
	FileWriter fw1= new FileWriter(fh);
	BufferedWriter bw1=new BufferedWriter(fw1);
	bw1.write(data);
	bw1.flush();
	bw1.close();
	
}



}
