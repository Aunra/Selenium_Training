package automation.org;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;


public class Common_Library {

	public ChromeDriver driver;

@BeforeMethod
 public void Openchrome() {
	 System.setProperty("webdriver.chrome.driver","D:\\Maven\\Wipro\\chromedriver.exe");
	 driver=new ChromeDriver();
	 driver.get("https://demo.opencart.com/");
	 driver.manage().window().maximize();
 }
 
 public void Close() {
	 driver.close();
 }
 

}
